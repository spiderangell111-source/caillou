package com.caillou.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [DiaryEntry::class, DiaryFolder::class, DiaryAttachment::class], version = 1, exportSchema = true)
abstract class CaillouDatabase : RoomDatabase() {
    abstract fun diaryDao(): DiaryDao

    companion object {
        @Volatile private var INSTANCE: CaillouDatabase? = null
        fun get(context: Context): CaillouDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, CaillouDatabase::class.java, "caillou.db")
                .build().also { INSTANCE = it }
        }
    }
}
