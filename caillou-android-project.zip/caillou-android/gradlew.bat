@echo off
set APP_HOME=%~dp0
set VERSION=8.10.2
set DIST=%USERPROFILE%\.gradle\wrapper\dists\gradle-%VERSION%-bin\local\gradle-%VERSION%\bin\gradle.bat
if not exist "%DIST%" (
  echo Please install Gradle %VERSION% or run gradlew from a network-enabled environment.
  exit /b 1
)
call "%DIST%" -p "%APP_HOME%" %*
