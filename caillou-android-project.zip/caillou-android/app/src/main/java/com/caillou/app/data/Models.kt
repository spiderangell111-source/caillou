package com.caillou.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "diary_entries")
data class DiaryEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val folderId: Long? = null,
    val tags: String = "",
    val favorite: Boolean = false,
    val archived: Boolean = false,
    val trashed: Boolean = false
)

@Entity(tableName = "folders")
data class DiaryFolder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val parentId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "attachments")
data class DiaryAttachment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entryId: Long,
    val uri: String,
    val displayName: String,
    val mimeType: String?,
    val addedAt: Long = System.currentTimeMillis()
)
