package com.caillou.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import androidx.room.withTransaction
import com.caillou.app.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

private val Paper = Color(0xFFF7F0EA)
private val Ink = Color(0xFF3D3030)
private val Rose = Color(0xFF956D73)
private val Muted = Color(0xFF8E7D78)
private val Card = Color(0xFFFFFBF7)

class MainActivity : ComponentActivity() {
    private lateinit var db: CaillouDatabase
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = CaillouDatabase.get(this)
        setContent { CaillouApp(db) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CaillouApp(db: CaillouDatabase) {
    val dao = db.diaryDao()
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    var tab by remember { mutableStateOf("Дневник") }
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<DiaryEntry?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var showFolderDialog by remember { mutableStateOf(false) }
    var folderName by remember { mutableStateOf("") }
    var pendingAttachment by remember { mutableStateOf<Uri?>(null) }
    val entries by (if (query.isBlank()) dao.observeEntries() else dao.searchEntries(query)).collectAsState(initial = emptyList())
    val folders by dao.observeFolders().collectAsState(initial = emptyList())
    val archive by dao.observeArchive().collectAsState(initial = emptyList())
    val trash by dao.observeTrash().collectAsState(initial = emptyList())
    val favorites by dao.observeFavorites().collectAsState(initial = emptyList())
    val attachments by dao.observeAllAttachments().collectAsState(initial = emptyList())
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pendingAttachment = uri
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            catch (_: Exception) { /* Some document providers grant temporary access only. */ }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Rose, background = Paper, surface = Card, onSurface = Ink)) {
        Scaffold(
            containerColor = Paper,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Paper).padding(horizontal = 22.dp, vertical = 18.dp)) {
                    Text("caillou", fontFamily = FontFamily.Serif, fontSize = 34.sp, color = Ink)
                    Text("личное пространство", color = Muted, fontSize = 12.sp, letterSpacing = 2.sp)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Card) {
                    listOf("Главная", "Дневник", "Галерея", "Календарь", "Архив").forEach { item ->
                        NavigationBarItem(selected = tab == item, onClick = { tab = item; query = "" },
                            icon = { Icon(when(item) { "Главная" -> Icons.Default.Home; "Дневник" -> Icons.Default.MenuBook; "Галерея" -> Icons.Default.PhotoLibrary; "Календарь" -> Icons.Default.CalendarMonth; else -> Icons.Default.Inventory2 }, contentDescription = item) },
                            label = { Text(item, fontSize = 10.sp) })
                    }
                }
            },
            floatingActionButton = {
                if (tab == "Дневник" || tab == "Главная") FloatingActionButton(onClick = { editing = null; pendingAttachment = null; showEditor = true }, containerColor = Rose, contentColor = Color.White) { Icon(Icons.Default.Add, contentDescription = "Новая запись") }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                when (tab) {
                    "Главная" -> {
                        Spacer(Modifier.height(8.dp))
                        Text("Твоё место для мыслей", fontFamily = FontFamily.Serif, fontSize = 25.sp, color = Ink)
                        Text("Здесь будут собираться записи и воспоминания.", color = Muted, modifier = Modifier.padding(top = 6.dp, bottom = 18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatCard("Записи", entries.size.toString(), Modifier.weight(1f))
                            StatCard("Избранное", favorites.size.toString(), Modifier.weight(1f))
                        }
                        Text("Последние записи", fontFamily = FontFamily.Serif, fontSize = 20.sp, color = Ink, modifier = Modifier.padding(top = 22.dp, bottom = 8.dp))
                        EntryList(entries.take(5), onOpen = { editing = it; showEditor = true }, onFavorite = { scope.launch { dao.toggleFavorite(it.id) } }, onDelete = { scope.launch { dao.moveToTrash(it.id) } }, onArchive = { scope.launch { dao.archiveEntry(it.id) } })
                    }
                    "Дневник" -> {
                        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 10.dp), placeholder = { Text("Поиск по записям и тегам") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(16.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                            Text("Мои записи", fontFamily = FontFamily.Serif, fontSize = 23.sp, color = Ink)
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = { showFolderDialog = true }) { Icon(Icons.Default.CreateNewFolder, null); Text("Папка") }
                        }
                        EntryList(entries, onOpen = { editing = it; showEditor = true }, onFavorite = { scope.launch { dao.toggleFavorite(it.id) } }, onDelete = { scope.launch { dao.moveToTrash(it.id) } }, onArchive = { scope.launch { dao.archiveEntry(it.id) } })
                    }
                    "Галерея" -> {
                        SectionTitle("Галерея", "Вложения, добавленные к записям")
                        if (attachments.isEmpty()) EmptyState("Пока здесь пусто", "Добавь файл или фотографию в запись дневника.")
                        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(attachments, key = { it.id }) { a -> Surface(color = Card, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.AttachFile, null, tint = Rose); Spacer(Modifier.width(10.dp)); Column { Text(a.displayName, color = Ink); Text(a.mimeType ?: "Файл", color = Muted, fontSize = 12.sp) } } } } }
                    }
                    "Календарь" -> {
                        SectionTitle("Календарь", "Хронология твоих записей")
                        if (entries.isEmpty()) EmptyState("Пока нет записей", "Новые записи появятся здесь по дате создания.")
                        else EntryList(entries.sortedByDescending { it.createdAt }, onOpen = { editing = it; showEditor = true }, onFavorite = { scope.launch { dao.toggleFavorite(it.id) } }, onDelete = { scope.launch { dao.moveToTrash(it.id) } }, onArchive = { scope.launch { dao.archiveEntry(it.id) } }, showDate = true)
                    }
                    "Архив" -> {
                        var archiveMode by remember { mutableStateOf(false) }
                        Row(verticalAlignment = Alignment.CenterVertically) { Text("Архив и корзина", fontFamily = FontFamily.Serif, fontSize = 23.sp, color = Ink); Spacer(Modifier.weight(1f)); TextButton(onClick = { archiveMode = !archiveMode }) { Text(if (archiveMode) "Корзина" else "Архив") } }
                        val list = if (archiveMode) trash else archive
                        if (list.isEmpty()) EmptyState(if (archiveMode) "Корзина пуста" else "Архив пуст", "Перемещённые сюда записи будут доступны в этом разделе.")
                        else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) { items(list, key = { it.id }) { e -> Surface(color = Card, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(e.title.ifBlank { "Без названия" }, color = Ink, fontWeight = FontWeight.SemiBold); Text(e.body.take(75), color = Muted, maxLines = 2) }; IconButton(onClick = { scope.launch { dao.restoreEntry(e.id) } }) { Icon(Icons.Default.Restore, "Восстановить", tint = Rose) } } } } }
                    }
                }
            }
        }
    }

    if (showEditor) {
        var title by remember(editing?.id) { mutableStateOf(editing?.title.orEmpty()) }
        var body by remember(editing?.id) { mutableStateOf(editing?.body.orEmpty()) }
        var tags by remember(editing?.id) { mutableStateOf(editing?.tags.orEmpty()) }
        var selectedFolderId by remember(editing?.id) { mutableStateOf(editing?.folderId) }
        var folderMenuExpanded by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showEditor = false },
            title = { Text(if (editing == null) "Новая страница" else "Редактирование", fontFamily = FontFamily.Serif) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true)
                    OutlinedTextField(body, { body = it }, label = { Text("Твоя запись") }, minLines = 5)
                    OutlinedTextField(tags, { tags = it }, label = { Text("Теги через запятую") }, singleLine = true)
                    Box {
                        OutlinedButton(onClick = { folderMenuExpanded = true }) { Icon(Icons.Default.Folder, null); Spacer(Modifier.width(6.dp)); Text(folders.firstOrNull { it.id == selectedFolderId }?.name ?: "Без папки") }
                        DropdownMenu(expanded = folderMenuExpanded, onDismissRequest = { folderMenuExpanded = false }) {
                            DropdownMenuItem(text = { Text("Без папки") }, onClick = { selectedFolderId = null; folderMenuExpanded = false })
                            folders.forEach { folder -> DropdownMenuItem(text = { Text(folder.name) }, onClick = { selectedFolderId = folder.id; folderMenuExpanded = false }) }
                        }
                    }
                    TextButton(onClick = { picker.launch(arrayOf("*/*")) }) { Icon(Icons.Default.AttachFile, null); Text("Добавить файл") }
                    pendingAttachment?.let { Text("Файл выбран: ${it.lastPathSegment ?: "вложение"}", color = Muted, fontSize = 12.sp) }
                }
            },
            confirmButton = { TextButton(onClick = {
                scope.launch {
                    val now = System.currentTimeMillis()
                    val id = if (editing == null) dao.insertEntry(DiaryEntry(title = title, body = body, tags = tags, folderId = selectedFolderId, createdAt = now, updatedAt = now))
                    else { dao.updateEntry(editing!!.copy(title = title, body = body, tags = tags, folderId = selectedFolderId, updatedAt = now)); editing!!.id }
                    pendingAttachment?.let { uri ->
                        val name = runCatching {
                            context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                                if (c.moveToFirst()) c.getString(0) else null
                            }
                        }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Вложение"
                        val mime = context.contentResolver.getType(uri)
                        dao.insertAttachment(DiaryAttachment(entryId = id, uri = uri.toString(), displayName = name, mimeType = mime))
                        pendingAttachment = null
                    }
                }
                showEditor = false
            }) { Text("Сохранить") } },
            dismissButton = { TextButton(onClick = { showEditor = false }) { Text("Отмена") } }
        )
    }
    if (showFolderDialog) AlertDialog(onDismissRequest = { showFolderDialog = false }, title = { Text("Новая папка") }, text = { OutlinedTextField(folderName, { folderName = it }, label = { Text("Название") }, singleLine = true) }, confirmButton = { TextButton(onClick = { if (folderName.isNotBlank()) scope.launch { dao.insertFolder(DiaryFolder(name = folderName.trim())) }; folderName = ""; showFolderDialog = false }) { Text("Создать") } }, dismissButton = { TextButton(onClick = { showFolderDialog = false }) { Text("Отмена") } })
}

@Composable private fun EntryList(list: List<DiaryEntry>, onOpen: (DiaryEntry) -> Unit, onFavorite: (DiaryEntry) -> Unit, onDelete: (DiaryEntry) -> Unit, onArchive: (DiaryEntry) -> Unit, showDate: Boolean = false) {
    if (list.isEmpty()) { EmptyState("Здесь пока тихо", "Нажми +, чтобы создать первую страницу."); return }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
        items(list, key = { it.id }) { e ->
            Surface(color = Card, shape = RoundedCornerShape(17.dp), modifier = Modifier.fillMaxWidth().clickable { onOpen(e) }) {
                Column(Modifier.padding(15.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(e.title.ifBlank { "Без названия" }, modifier = Modifier.weight(1f), color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        if (e.favorite) Icon(Icons.Default.Favorite, null, tint = Rose, modifier = Modifier.size(16.dp))
                    }
                    if (e.body.isNotBlank()) Text(e.body, color = Muted, maxLines = 3, modifier = Modifier.padding(top = 5.dp))
                    if (e.tags.isNotBlank()) Text(e.tags, color = Rose, fontSize = 11.sp, modifier = Modifier.padding(top = 7.dp))
                    if (showDate) Text(java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.getDefault()).format(java.util.Date(e.createdAt)), color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        IconButton(onClick = { onFavorite(e) }) { Icon(if (e.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Избранное", tint = Rose) }
                        IconButton(onClick = { onArchive(e) }) { Icon(Icons.Default.Archive, "В архив", tint = Muted) }
                        IconButton(onClick = { onDelete(e) }) { Icon(Icons.Default.DeleteOutline, "В корзину", tint = Muted) }
                    }
                }
            }
        }
    }
}

@Composable private fun SectionTitle(title: String, subtitle: String) { Text(title, fontFamily = FontFamily.Serif, fontSize = 25.sp, color = Ink, modifier = Modifier.padding(top = 6.dp)); Text(subtitle, color = Muted, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)) }
@Composable private fun EmptyState(title: String, subtitle: String) { Column(Modifier.fillMaxWidth().padding(top = 45.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.AutoStories, null, tint = Rose, modifier = Modifier.size(34.dp)); Text(title, fontFamily = FontFamily.Serif, fontSize = 19.sp, color = Ink, modifier = Modifier.padding(top = 10.dp)); Text(subtitle, color = Muted, fontSize = 13.sp) } }
@Composable private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) { Surface(modifier, color = Card, shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(15.dp)) { Text(value, fontSize = 25.sp, fontFamily = FontFamily.Serif, color = Rose); Text(label, color = Muted, fontSize = 12.sp) } } }
