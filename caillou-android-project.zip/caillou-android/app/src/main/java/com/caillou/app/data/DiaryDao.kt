package com.caillou.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DiaryDao {
    @Query("SELECT * FROM diary_entries WHERE trashed = 0 AND archived = 0 ORDER BY updatedAt DESC")
    fun observeEntries(): Flow<List<DiaryEntry>>

    @Query("SELECT * FROM diary_entries WHERE trashed = 0 AND archived = 0 AND (title LIKE '%' || :query || '%' OR body LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%') ORDER BY updatedAt DESC")
    fun searchEntries(query: String): Flow<List<DiaryEntry>>

    @Query("SELECT * FROM diary_entries WHERE archived = 1 AND trashed = 0 ORDER BY updatedAt DESC")
    fun observeArchive(): Flow<List<DiaryEntry>>

    @Query("SELECT * FROM diary_entries WHERE trashed = 1 ORDER BY updatedAt DESC")
    fun observeTrash(): Flow<List<DiaryEntry>>

    @Query("SELECT * FROM diary_entries WHERE favorite = 1 AND trashed = 0 ORDER BY updatedAt DESC")
    fun observeFavorites(): Flow<List<DiaryEntry>>

    @Insert
    suspend fun insertEntry(entry: DiaryEntry): Long

    @Update
    suspend fun updateEntry(entry: DiaryEntry)

    @Query("UPDATE diary_entries SET trashed = 1, updatedAt = :now WHERE id = :id")
    suspend fun moveToTrash(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE diary_entries SET trashed = 0, archived = 0, updatedAt = :now WHERE id = :id")
    suspend fun restoreEntry(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE diary_entries SET archived = 1, updatedAt = :now WHERE id = :id")
    suspend fun archiveEntry(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE diary_entries SET favorite = NOT favorite, updatedAt = :now WHERE id = :id")
    suspend fun toggleFavorite(id: Long, now: Long = System.currentTimeMillis())

    @Query("DELETE FROM diary_entries WHERE id = :id")
    suspend fun permanentlyDelete(id: Long)

    @Query("SELECT * FROM folders ORDER BY name COLLATE NOCASE")
    fun observeFolders(): Flow<List<DiaryFolder>>

    @Insert
    suspend fun insertFolder(folder: DiaryFolder): Long

    @Insert
    suspend fun insertAttachment(attachment: DiaryAttachment): Long

    @Query("SELECT * FROM attachments WHERE entryId = :entryId ORDER BY addedAt")
    fun observeAttachments(entryId: Long): Flow<List<DiaryAttachment>>

    @Query("SELECT * FROM attachments ORDER BY addedAt DESC")
    fun observeAllAttachments(): Flow<List<DiaryAttachment>>
}
